import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FlightRequest } from '../models';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  constructor(
    private http: HttpClient,
    private router: Router) { }
}


getFlights() : Observable<FlightRequest[]> {
  return this.http.get<FlightRequest[]>()
}