import * as moment from 'moment';

export class FlightRequest {

    id: number;
    FlightNo: string;
    StartTime: Date;
    EndTime: Date;
    FlightCapacity: number;
    DepartureCity: string;
    ArrivalCity: string;

    
    dateFormat(dt) {
        if(dt != undefined) {            
            return moment(dt, 'YYYY-MM-DD').format();
        }
        return dt;
    }

}
