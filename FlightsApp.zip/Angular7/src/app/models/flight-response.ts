export class FlightResponse {
    id: number;
    FlightNo: string;
    StartTime: Date;
    EndTime: Date;
    FlightCapacity: number;
    DepartureCity: string;
    ArrivalCity: string;
}
