import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/shared/user.service';
import { error } from 'util';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styles: []
})
export class RegistrationComponent implements OnInit {

  constructor(public service: UserService, private toastr: ToastrService) { }

  ngOnInit() {
  }

  onSubmit() {
    this.service.register().subscribe(
      (res: any) => {
        if (res.succeeded) {
          this.service.formModel.reset();
          this.toastr.success('New User Created', 'Registration Successful');
        } else {
          res.errors.forEach(element => {
            switch (element.code) {
              case 'DuplicateUserName':
                //UserName already taken
                this.toastr.error('UserName is already taken', 'Registration Failed');
                break;

                default:
                  //Registration Failed
                  this.toastr.error(element.description , 'Registration Failed');
                  break;
            }
          });
        }
      },
      err => {
        console.log(err);
      }
    );
  }
}
