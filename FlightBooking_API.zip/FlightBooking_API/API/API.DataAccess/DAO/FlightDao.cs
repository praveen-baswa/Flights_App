﻿using API.DataAccess.Interfaces;
using API.Models;
using API.Models.Request;
using API.Models.Response;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.DataAccess.DAO
{
    public class FlightDao :IFlightDao
    {
        private readonly FlightDBContext _context;

        public FlightDao(FlightDBContext context)
        {
            _context = context;
        }

        public async Task<PagingResponse<TblFlight>> GetFlights(FlightRequest request)
        {
            var filteredFlights = _context.TblFlight as IQueryable<TblFlight>;

            if (request.Id != 0)
            {
                filteredFlights = filteredFlights.Where(x => x.Id == request.Id);
            }

            if (!string.IsNullOrEmpty(request.FlightNo))
            {
                filteredFlights = filteredFlights.Where(x => x.FlightNo.Contains(request.FlightNo));
            }

            //if (request.ArrivalCity !=0)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.ArrivalCity == request.ArrivalCity);
            //}

            //if (request.DepartureCity !=0)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.DepartureCity == request.DepartureCity);
            //}

            //if (request.FlightCapacity != 0)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.FlightCapacity == request.FlightCapacity);
            //}

           
            //var startDate = request.StartTime.DateParse();
            //if (dateOfBirth.HasValue)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.DOB == dateOfBirth.Value.Date);
            //}

            //if (request.Gender != 0)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.Gender == request.Gender);
            //}

            //var dateOfInjury = request.Doij.DateParse();
            //if (dateOfInjury.HasValue)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.HeadInjury.Doij == dateOfInjury.Value.Date);
            //}

            //var dateOfAdmission = request.Doa.DateParse();
            //if (dateOfAdmission.HasValue)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.Admission.Doa == dateOfAdmission.Value.Date);
            //}

            //if (request.PPSCode != 0)
            //{
            //    filteredFlights = filteredFlights.Where(x => x.Ppscode == request.PPSCode);
            //}

            var flightCount = filteredFlights.Count();

            //var sortProperty = TypeDescriptor.GetProperties(typeof(Patient)).Find(request.SortBy, true);
            IQueryable<TblFlight> sortedFlights;
            //PropertyDescriptor sortProperty;
            //if (request.SortDirection == "")
            //{
                sortedFlights = filteredFlights.OrderByDescending(x => x.StartTime);
            //}
            //else
            //{
            //    //for any sortby field on tblPatient               
            //        var sortProperty = TypeDescriptor.GetProperties(typeof(TblFlight)).Find(request.SortBy, true);
            //    sortedFlights = request.SortAsc ?
            //            filteredFlights.OrderBy(x => sortProperty.GetValue(x)) :
            //            filteredFlights.OrderByDescending(x => sortProperty.GetValue(x));

            //}

            //var sortedPatients = request.SortAsc ? filteredFlights.OrderBy(x => sortProperty.GetValue(x)) : filteredFlights.OrderByDescending(x => sortProperty.GetValue(x));

            //var flights = await sortedFlights.Skip(request.Skip).Take(request.PageSize).ToListAsync();
            var flights = await sortedFlights.Skip(request.Skip).Take(5).ToListAsync();

            var resp = new PagingResponse<TblFlight>(flights, flightCount);

            return resp;

        }

        //public async Task<PagingResponse<TblFlight>> GetFlights_Duplicate(FlightNewRequest request)
        //{
        //    var flights = _context.TblFlight as IQueryable<TblFlight>;

        //    flights = flights.Where(x => x.FlightNo == request.FlightNo);

        //    //for testing only
        //    //patients = patients.Where(x => x.URNo == request.URNo ||
        //    //    (x.Surname == request.Surname && x.Admission.Doa == request.DOA));

        //    var flights_duplicate_display = await flights.Skip(request.Skip).Take(request.PageSize == 0 ? flights.Count() : request.PageSize).ToListAsync();

        //    var flightTotalCount = flights.Count();

        //    var resp = new PagingResponse<TblFlight>(flights_duplicate_display, flightTotalCount);

        //    return resp;
        //}

        public async Task<TblFlight> GetFlightById(int flightid)
        {
            return await _context.TblFlight.FindAsync(flightid);
        }


        public async Task<TblFlight> SaveFlightData(TblFlight flight)
        {
            if (flight.Id == 0)
            {
                _context.TblFlight.Add(flight);
            }
            else
            {
                _context.TblFlight.Update(flight);
            }

            return await _context.SaveChangesAsync() == 1 ? flight : null;
        }



        ////public async Task<List<FlightOptions>> GetFlightOptions()
        ////{
        ////    return await _context.FlightOptions.ToListAsync();
        ////}

        ////public async Task<List<GeneralOptions>> GetGeneralOptions()
        ////{
        ////    return await _context.GeneralOptions.ToListAsync();
        ////}

        ////public async Task<int> GetPatientMaxId(int? CodeType = (int)ResearchCodeIndexes.Id)
        ////{

        ////    if (CodeType == (int)ResearchCodeIndexes.Id)
        ////    {
        ////        return await _context.Patients.MaxAsync(m => m.Id);
        ////    }
        ////    else if (CodeType == (int)ResearchCodeIndexes.ResearchCode)
        ////    {
        ////        return await _context.Patients.MaxAsync(m => m.ResearchCode.Value);
        ////    }
        ////    else if (CodeType == (int)ResearchCodeIndexes.PPSCode)
        ////    {
        ////        return await _context.Patients.MaxAsync(m => m.Ppscode.Value);
        ////    }
        ////    else if (CodeType == (int)ResearchCodeIndexes.CCSCode)
        ////    {
        ////        return await _context.Patients.MaxAsync(m => m.Ccscode.Value);
        ////    }
        ////    else
        ////    {
        ////        return -1;
        ////    }


        ////}

        //public static DateTime? DateParse(this String str)
        //{
        //    if (!string.IsNullOrEmpty(str))
        //    {
        //        return DateTime.Parse(str);
        //    }
        //    return null;
        //}
    }
}
