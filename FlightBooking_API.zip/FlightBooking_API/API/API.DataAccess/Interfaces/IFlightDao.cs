﻿using API.Models;
using API.Models.Request;
using API.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace API.DataAccess.Interfaces
{
    public interface IFlightDao
    {
        Task<PagingResponse<TblFlight>> GetFlights(FlightRequest request);
        Task<TblFlight> GetFlightById(int flighttId);
        Task<TblFlight> SaveFlightData(TblFlight flight);
    }
}
