﻿using API.Models.Request;
using API.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace API.Service.Interfaces
{
    public interface IFlightService
    {
        Task<PagingResponse<FlightResponse>> GetFlights(FlightRequest request);
        Task<FlightResponse> GetFlight(int flighttId);
        Task<FlightResponse> SaveFlightData(FlightRequest request);
    }
}
