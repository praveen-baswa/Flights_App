﻿using API.Models;
using API.Models.Response;
using API.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace API.Service.Services
{
    public class HelperService : IHelperService
    {
        public List<OptionsResponse> GetOptions(List<LookupDataOptions> options, int optionIndex, bool withEmptyItem)
        {
            List<OptionsResponse> items = new List<OptionsResponse>();
            items = options.Where(w => w.OptionIndex == optionIndex).OrderBy(o => o.SortOrder).ThenBy(t => t.Id)
                                .Select(s => new OptionsResponse { Id = s.Id.ToString(), Description = s.Description }).ToList();
            if (withEmptyItem)
            {
                items.Insert(0, new OptionsResponse() { Id = null, Description = null });
            }
            return items;
        }

        public List<OptionsResponse> GetOptions_SortOrder_Description(List<LookupDataOptions> options, int optionIndex, bool withEmptyItem)
        {
            List<OptionsResponse> items = new List<OptionsResponse>();
            items = options.Where(w => w.OptionIndex == optionIndex).OrderBy(o => o.SortOrder).ThenBy(t => t.Description)
                                .Select(s => new OptionsResponse { Id = s.Id.ToString(), Description = s.Description }).ToList();
            if (withEmptyItem)
            {
                items.Insert(0, new OptionsResponse() { Id = null, Description = null });
            }
            return items;
        }



    }
}
