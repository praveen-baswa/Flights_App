﻿using API.DataAccess;
using API.DataAccess.Interfaces;
using API.Models;
using API.Models.Request;
using API.Models.Response;
using API.Service.Interfaces;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.Service.Services
{
    public class FlightService: IFlightService
    {
        private IMapper _mapper;
        private IFlightDao _flightDao;
       
        public FlightService(IFlightDao flightDao, IMapper mapper)
        {
            _flightDao = flightDao;
            _mapper = mapper;          
        }

        public async Task<PagingResponse<FlightResponse>> GetFlights(FlightRequest request)
        {
            var flights = await _flightDao.GetFlights(request);
            var response = _mapper.Map<PagingResponse<FlightResponse>>(flights);
            return response;
        }

        public async Task<FlightResponse> GetFlight(int flightId)
        {
            var response = new FlightResponse();
            var FlightData = await _flightDao.GetFlightById(flightId);
            if (FlightData != null)
            {
                response = _mapper.Map<FlightResponse>(FlightData);
            }

            //response.CityOptions = _helper.GetOptions(options, (int)CityOptionIndexes.CityOptionIndex, true);
            
            return response;
            }

        public async Task<FlightResponse> SaveFlightData(FlightRequest request)
        {
            
            TblFlight ft = new TblFlight();

            //assign CreatedBy, CreatedDateTime for insert and update case
            if (request.Id == 0)
            {
                //insert                
                ft = _mapper.Map<TblFlight>(request);              
            }
            else
            {
                //update
                var flightData = await _flightDao.GetFlightById(request.Id);

                //map request to Patient and assign to pt for saving into DB
                //to avoid error 'Id' is being tracked, need to do _mapper.Map(request, patientData);
                ft = _mapper.Map(request, flightData);
            }

                  

            //save ft into DB
            TblFlight ftSaveResult = await _flightDao.SaveFlightData(ft);

            var ftResponse = new FlightResponse();

            //if saved successfully,  
            if (ftSaveResult != null)
            {       
                ftResponse = _mapper.Map<FlightResponse>(ftSaveResult);
            }
            //if NOT saved successfully,
            else
            {
                ftResponse = null;
            }

            return ftResponse;
            
        }
    }
}
