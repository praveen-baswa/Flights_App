﻿using API.Models;
using API.Models.Request;
using API.Models.Response;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace API.Service.Services
{
    class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<TblFlight, FlightResponse>();
            CreateMap<PagingResponse<TblFlight>, PagingResponse<FlightResponse>>();
            CreateMap<FlightResponse, TblFlight>();
            CreateMap<FlightRequest, TblFlight>();
        }
    }
}
