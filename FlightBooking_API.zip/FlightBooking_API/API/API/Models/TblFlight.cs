﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tbl_Flight")]
    public partial class TblFlight
    {
        public TblFlight()
        {
            TblBooking = new HashSet<TblBooking>();
            TblPassenger = new HashSet<TblPassenger>();
        }

        public int Id { get; set; }
        [StringLength(100)]
        public string FlightNo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? StartTime { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? EndTime { get; set; }
        public int? FlightCapacity { get; set; }
        public int? DepartureCity { get; set; }
        public int? ArrivalCity { get; set; }

        [ForeignKey("ArrivalCity")]
        [InverseProperty("TblFlightArrivalCityNavigation")]
        public virtual TlkpCity ArrivalCityNavigation { get; set; }
        [ForeignKey("DepartureCity")]
        [InverseProperty("TblFlightDepartureCityNavigation")]
        public virtual TlkpCity DepartureCityNavigation { get; set; }
        [InverseProperty("Flight")]
        public virtual ICollection<TblBooking> TblBooking { get; set; }
        [InverseProperty("Flight")]
        public virtual ICollection<TblPassenger> TblPassenger { get; set; }
    }
}
