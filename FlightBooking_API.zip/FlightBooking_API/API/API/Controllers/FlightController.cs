﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.DataAccess;
using API.Models.Request;
using API.Models.Response;
using API.Service.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightController : ControllerBase
    {
        private readonly IFlightService _flightService;
    
        private readonly IMapper _mapper;
        private readonly FlightDBContext _context;

        public FlightController(FlightDBContext context, IFlightService flightService, IMapper mapper)
        {
            _flightService = flightService;
            _mapper = mapper;
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery]FlightRequest request)
        {
            var response = await _flightService.GetFlights(request);
            if (response != null)
            {
                return StatusCode(StatusCodes.Status200OK, response);
            }
            return StatusCode(StatusCodes.Status400BadRequest);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<FlightResponse>> Get(int id)
        {
            var response = await _flightService.GetFlight(id);
            if (response != null)
            {
                return StatusCode(StatusCodes.Status200OK, response);
            }
            return StatusCode(StatusCodes.Status400BadRequest);
        }

        [HttpPost("save")]
        public async Task<ActionResult<FlightResponse>> Post([FromBody] FlightRequest request)
        {
            var fr = await _flightService.SaveFlightData(request);

            return fr != null ? StatusCode(StatusCodes.Status200OK, fr) : StatusCode(StatusCodes.Status400BadRequest, "Failed to save 'Flight Info' changes to the database");

        }
    }
}