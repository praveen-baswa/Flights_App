﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using API.Models.Entities;
using Microsoft.AspNetCore.Identity;
using API.DataAccess;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationUserController : ControllerBase
    {

        private UserManager<ApplicationUser> _userManager;
        private SignInManager<ApplicationUser> _signInManager;
        private readonly FlightDBContext _context;

        public ApplicationUserController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, FlightDBContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
        }

        [HttpPost]
        [Route("Register")]
        //POST : /api/ApplicationUser/Register

        public async Task<Object> PostApplicationUser(ApplicationUserModel model)
        {
            var applicationUser = new ApplicationUser()
            {
                UserName = model.UserName,
                Email = model.Email,
                FullName = model.FullName
            };

            try
            {
                var result = await _userManager.CreateAsync(applicationUser, model.Password);
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("Users")]
        //Get /api/ApplicationUser/Users
        public ActionResult<List<ApplicationUser>> Get()
        {
            var userList = new List<ApplicationUser>();
            userList = _context.ApplicationUsers.ToList();
            return userList;
        }

        [HttpGet]
        [Route("Users/{userName}")]
        //Get /api/ApplicationUser/Users/{userName}
        public ActionResult<ApplicationUser> Get(string userName)
        {
            var userDetails = new ApplicationUser();
            userDetails = _context.ApplicationUsers.Where(a => a.UserName == userName).FirstOrDefault();
            return userDetails;
        }

    }
}