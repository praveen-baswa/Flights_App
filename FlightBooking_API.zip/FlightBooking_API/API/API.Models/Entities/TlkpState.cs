﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tlkp_State")]
    public partial class TlkpState
    {
        public TlkpState()
        {
            TlkpCity = new HashSet<TlkpCity>();
        }

        public int Id { get; set; }
        [StringLength(100)]
        public string Description { get; set; }

        [InverseProperty("State")]
        public virtual ICollection<TlkpCity> TlkpCity { get; set; }
    }
}
