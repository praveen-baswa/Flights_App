﻿using System;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Entities
{
    public class ApplicationUser : IdentityUser
    {
        [System.ComponentModel.DataAnnotations.Schema.Column(TypeName = "nvarchar(150)")]
        public string FullName { get; set; }
        
    }

    
}
