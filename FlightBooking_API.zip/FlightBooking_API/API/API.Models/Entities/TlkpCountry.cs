﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tlkp_Country")]
    public partial class TlkpCountry
    {
        public TlkpCountry()
        {
            TlkpCity = new HashSet<TlkpCity>();
        }

        public int Id { get; set; }
        [StringLength(100)]
        public string Description { get; set; }

        [InverseProperty("Country")]
        public virtual ICollection<TlkpCity> TlkpCity { get; set; }
    }
}
