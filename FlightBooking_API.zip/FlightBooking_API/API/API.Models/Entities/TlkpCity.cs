﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tlkp_City")]
    public partial class TlkpCity
    {
        public TlkpCity()
        {
            TblFlightArrivalCityNavigation = new HashSet<TblFlight>();
            TblFlightDepartureCityNavigation = new HashSet<TblFlight>();
        }

        public int Id { get; set; }
        [StringLength(100)]
        public string Description { get; set; }
        [Column("State_Id")]
        public int? StateId { get; set; }
        [Column("Country_Id")]
        public int? CountryId { get; set; }

        [ForeignKey("CountryId")]
        [InverseProperty("TlkpCity")]
        public virtual TlkpCountry Country { get; set; }
        [ForeignKey("StateId")]
        [InverseProperty("TlkpCity")]
        public virtual TlkpState State { get; set; }
        [InverseProperty("ArrivalCityNavigation")]
        public virtual ICollection<TblFlight> TblFlightArrivalCityNavigation { get; set; }
        [InverseProperty("DepartureCityNavigation")]
        public virtual ICollection<TblFlight> TblFlightDepartureCityNavigation { get; set; }
    }
}
