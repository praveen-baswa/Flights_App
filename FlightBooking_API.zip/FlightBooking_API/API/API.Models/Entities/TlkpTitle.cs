﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tlkp_Title")]
    public partial class TlkpTitle
    {
        public TlkpTitle()
        {
            TblPassenger = new HashSet<TblPassenger>();
        }

        public int Id { get; set; }
        [StringLength(100)]
        public string Description { get; set; }

        [InverseProperty("TitleNavigation")]
        public virtual ICollection<TblPassenger> TblPassenger { get; set; }
    }
}
