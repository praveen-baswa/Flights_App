﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tbl_Booking")]
    public partial class TblBooking
    {
        public int Id { get; set; }
        public int? PassengerId { get; set; }
        public int? FlightId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? BookingDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? StartDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        [StringLength(256)]
        public string UserName { get; set; }

        [ForeignKey("FlightId")]
        [InverseProperty("TblBooking")]
        public virtual TblFlight Flight { get; set; }
        [ForeignKey("PassengerId")]
        [InverseProperty("TblBooking")]
        public virtual TblPassenger Passenger { get; set; }
    }
}
