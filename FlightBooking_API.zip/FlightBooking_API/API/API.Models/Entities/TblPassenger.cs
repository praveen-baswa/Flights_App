﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace API.Models
{
    [Table("tbl_Passenger")]
    public partial class TblPassenger
    {
        public TblPassenger()
        {
            TblBooking = new HashSet<TblBooking>();
        }

        public int Id { get; set; }
        public int? Title { get; set; }
        [StringLength(200)]
        public string FirstName { get; set; }
        [StringLength(200)]
        public string LastName { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? DateofBirth { get; set; }
        public int? FlightId { get; set; }

        [ForeignKey("FlightId")]
        [InverseProperty("TblPassenger")]
        public virtual TblFlight Flight { get; set; }
        [ForeignKey("Title")]
        [InverseProperty("TblPassenger")]
        public virtual TlkpTitle TitleNavigation { get; set; }
        [InverseProperty("Passenger")]
        public virtual ICollection<TblBooking> TblBooking { get; set; }
    }
}
