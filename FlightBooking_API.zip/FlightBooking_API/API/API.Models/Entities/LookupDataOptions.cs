﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public abstract class LookupDataOptions
    {
        [Key]
        public int RowId { get; set; }
        public int OptionIndex { get; set; }
        public int Id { get; set; }
        public string Description { get; set; }
        public int? SortOrder { get; set; }

    }
}
