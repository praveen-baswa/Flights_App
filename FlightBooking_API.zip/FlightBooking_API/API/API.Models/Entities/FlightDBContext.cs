﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace API.Models
{
    public partial class FlightDBContext : DbContext
    {
        public FlightDBContext()
        {
        }

        public FlightDBContext(DbContextOptions<FlightDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AspNetRoles> AspNetRoles { get; set; }
        public virtual DbSet<AspNetUserClaims> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserLogins> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUserRoles> AspNetUserRoles { get; set; }
        public virtual DbSet<AspNetUserTokens> AspNetUserTokens { get; set; }
        public virtual DbSet<AspNetUsers> AspNetUsers { get; set; }
        public virtual DbSet<TblBooking> TblBooking { get; set; }
        public virtual DbSet<TblFlight> TblFlight { get; set; }
        public virtual DbSet<TblPassenger> TblPassenger { get; set; }
        public virtual DbSet<TlkpCity> TlkpCity { get; set; }
        public virtual DbSet<TlkpCountry> TlkpCountry { get; set; }
        public virtual DbSet<TlkpState> TlkpState { get; set; }
        public virtual DbSet<TlkpTitle> TlkpTitle { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\;Database=FLIGHTDB_01;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<AspNetRoles>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<AspNetUserLogins>(entity =>
            {
                entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });
            });

            modelBuilder.Entity<AspNetUserRoles>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RoleId });
            });

            modelBuilder.Entity<AspNetUserTokens>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });
            });

            modelBuilder.Entity<AspNetUsers>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<TblBooking>(entity =>
            {
                entity.HasOne(d => d.Flight)
                    .WithMany(p => p.TblBooking)
                    .HasForeignKey(d => d.FlightId)
                    .HasConstraintName("FK_tbl_Booking_tbl_Flight_Id");

                entity.HasOne(d => d.Passenger)
                    .WithMany(p => p.TblBooking)
                    .HasForeignKey(d => d.PassengerId)
                    .HasConstraintName("FK_tbl_Booking_tbl_Passenger_Id");
            });

            modelBuilder.Entity<TblFlight>(entity =>
            {
                entity.Property(e => e.FlightNo).IsUnicode(false);

                entity.HasOne(d => d.ArrivalCityNavigation)
                    .WithMany(p => p.TblFlightArrivalCityNavigation)
                    .HasForeignKey(d => d.ArrivalCity)
                    .HasConstraintName("FK_tbl_Flight_tlkp_City_ArrivalCity_Id");

                entity.HasOne(d => d.DepartureCityNavigation)
                    .WithMany(p => p.TblFlightDepartureCityNavigation)
                    .HasForeignKey(d => d.DepartureCity)
                    .HasConstraintName("FK_tbl_Flight_tlkp_City_DepartureCity_Id");
            });

            modelBuilder.Entity<TblPassenger>(entity =>
            {
                entity.Property(e => e.FirstName).IsUnicode(false);

                entity.Property(e => e.LastName).IsUnicode(false);

                entity.HasOne(d => d.Flight)
                    .WithMany(p => p.TblPassenger)
                    .HasForeignKey(d => d.FlightId)
                    .HasConstraintName("FK_tbl_Passenger_tbl_Flight_Id");

                entity.HasOne(d => d.TitleNavigation)
                    .WithMany(p => p.TblPassenger)
                    .HasForeignKey(d => d.Title)
                    .HasConstraintName("FK_tbl_Passenger_tlkp_Title");
            });

            modelBuilder.Entity<TlkpCity>(entity =>
            {
                entity.Property(e => e.Description).IsUnicode(false);
            });

            modelBuilder.Entity<TlkpCountry>(entity =>
            {
                entity.Property(e => e.Description).IsUnicode(false);
            });

            modelBuilder.Entity<TlkpState>(entity =>
            {
                entity.Property(e => e.Description).IsUnicode(false);
            });

            modelBuilder.Entity<TlkpTitle>(entity =>
            {
                entity.Property(e => e.Description).IsUnicode(false);
            });
        }
    }
}
