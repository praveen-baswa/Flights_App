﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Response
{
    public class PagingResponse<T>
    {
        public PagingResponse() { }
        public IList<T> Rows { get; set; }
        public int TotalRows { get; set; }

        public PagingResponse(IList<T> rows, int totRows)
        {           
            Rows = rows;
            TotalRows = totRows;
        }      

    }
}
