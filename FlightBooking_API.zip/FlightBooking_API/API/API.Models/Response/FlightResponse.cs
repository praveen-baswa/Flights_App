﻿using API.Models.Request;
using System;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Response
{
    public class FlightResponse //: FlightRequest
    {
        public int Id { get; set; }
        public string FlightNo { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int? FlightCapacity { get; set; }
        public int? DepartureCity { get; set; }
        public int? ArrivalCity { get; set; }
        public List<OptionsResponse> CityOptions { get; set; }        
    }
}
