﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Response
{
    public class OptionsResponse
    {
        public string Id { get; set; }
        public string Description { get; set; }
    }
}
