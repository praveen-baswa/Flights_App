﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Request
{
    public abstract class PagingRequest
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public string SortBy { get; set; }
        public bool SortAsc { get; set; }
        public string SortDirection { get; set; }

        public int Skip { get => PageIndex * PageSize; }
    }
}
