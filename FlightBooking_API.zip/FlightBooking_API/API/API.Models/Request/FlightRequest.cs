﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Models.Request
{
    public class FlightRequest : PagingRequest
    {
        public int Id { get; set; }      
        public string FlightNo { get; set; }        
        public DateTime StartTime { get; set; }       
        public DateTime EndTime { get; set; }
        public int? FlightCapacity { get; set; }
        public int? DepartureCity { get; set; }
        public int? ArrivalCity { get; set; }
    }
}
